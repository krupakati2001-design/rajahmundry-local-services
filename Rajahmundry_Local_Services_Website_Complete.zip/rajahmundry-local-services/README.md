# Rajahmundry Local Services Website

## Open in VS Code
1. Extract this ZIP.
2. Open the `rajahmundry-local-services` folder in VS Code.
3. Open `index.html`.
4. For the easiest local preview, install the VS Code extension **Live Server**.
5. Right-click `index.html` → **Open with Live Server**.

## Pages
- Home
- Auto / Taxi
- Restaurants
- Cafes
- Hotels
- Local Services
- Contact / Location

## Before publishing
Replace the demo business names, phone numbers, ratings and descriptions with verified information.
The Google Maps button opens a search for Rajahmundry.
The contact form currently works only as a front-end demo and needs a backend/form service to actually receive messages.


## Restaurant listings
The Restaurants page has been populated using the Rajahmundry listings visible on Restaurant Guru:
https://restaurant-guru.in/Rajahmundry

Ratings/vote counts are only a snapshot. Verify each business's current details before using them commercially.
